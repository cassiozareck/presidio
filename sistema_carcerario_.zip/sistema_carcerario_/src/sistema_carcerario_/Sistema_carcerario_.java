/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistema_carcerario_;

import com.mycompany.sistema_carcerario.view.MainFrame;

/**
 *
 * @author m138824
 */
public class Sistema_carcerario_ {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Inicando Sistema Carcerário");
        new MainFrame();
    }
    
}
