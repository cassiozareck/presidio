/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistema_carcerario;

import com.mycompany.sistema_carcerario.view.MainFrame;

/**
 *
 * @author m138824
 */
public class Sistema_carcerario {

    public static void main(String[] args) {
        System.out.println("Inicando Sistema Carcerário");
        new MainFrame();
        
        // Antigo
    }
}
